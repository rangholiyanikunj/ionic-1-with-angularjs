app.controller('mainCtrl', function($scope, $ionicModal, $timeout) {
  console.log("this is main controller")
})

